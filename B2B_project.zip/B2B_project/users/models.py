from django.db import models
# Create your models here.


class Users(models.Model):
    
    def upload_photo(self, filename):
        return f"users/photo/{filename}"
    
    user_email = models.EmailField(max_length=50, unique=True, default="")
    first_name = models.CharField(max_length=100, default="")
    last_name = models.CharField(max_length=100, default="")
    age = models.IntegerField(default=18)
    address = models.CharField(max_length=250, default="")
    image = models.ImageField(upload_to=upload_photo, blank=True)
    
    def __str__(self):
        return f"{self.user_email} - {self.first_name}"
