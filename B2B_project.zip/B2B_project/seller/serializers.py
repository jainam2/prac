from rest_framework import serializers
from seller.models import seller_profile

class SellerSerializer(serializers.ModelSerializer):

	class Meta:
		model = seller_profile
		fields = "__all__"
		