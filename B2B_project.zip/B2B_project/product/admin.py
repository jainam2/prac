from django.contrib import admin
from product.models import product
# Register your models here.

admin.site.register(product)
