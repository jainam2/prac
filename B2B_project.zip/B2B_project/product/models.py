from django.db import models
from seller.models import seller_profile


# Create your models here.

class product(models.Model):
    """
    product features: name, id, seller name, image, mrp, wsp, rating,
            seller id, category, quantity, COD, favourite
    """

    def upload_photo(self, filename):
        return f"product/photo/{filename}"

    product_id = models.AutoField
    product_name = models.CharField(max_length=50, default="")
    product_img = models.ImageField(upload_to=upload_photo, blank=True)
    mrp = models.FloatField(default=0.00)
    wsp = models.FloatField(default=0.00)
    rating = models.FloatField(default=0.00)
    category = models.CharField(max_length=50, default="")
    quantity = models.IntegerField(default=0)
    COD = models.BooleanField(default=True)
    favourite = models.BooleanField(default=True)
    seller_info = models.ForeignKey(seller_profile, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.product_id} - {self.product_name}"
