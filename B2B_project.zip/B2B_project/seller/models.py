from django.db import models

# Create your models here.


class seller_profile(models.Model):
    """"
    seller features: id, name, age, image(optional), 
            address, contact number, is approved.
    """
    def upload_photo(self, filename):
        return f"seller/photo/{filename}"

    seller_id = models.AutoField
    seller_name = models.CharField(max_length=50, default="")
    seller_age = models.IntegerField(default=18)
    seller_image = models.ImageField(upload_to=upload_photo)
    seller_address = models.CharField(max_length=250)
    seller_contact = models.IntegerField(default="")
    seller_is_approved = models.BooleanField(default=True)
    
    def __str__(self):
        return f"{self.seller_name} - {self.seller_id}"