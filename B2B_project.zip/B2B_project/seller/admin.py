from django.contrib import admin
from seller.models import seller_profile
# Register your models here.


admin.site.register(seller_profile)
